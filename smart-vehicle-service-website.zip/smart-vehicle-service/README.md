# Smart Vehicle Service Website
Browser-based Flask + MongoDB website.
GitHub -> Render -> MongoDB Atlas.
Local: pip install -r requirements.txt; copy .env.example to .env; python app.py
Open http://127.0.0.1:5000
Render build: pip install -r requirements.txt
Render start: gunicorn app:app
