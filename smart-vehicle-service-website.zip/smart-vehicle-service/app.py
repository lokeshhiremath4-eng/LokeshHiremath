import os
from datetime import datetime
from flask import Flask,render_template,request,redirect,url_for,flash,jsonify
from pymongo import MongoClient
from dotenv import load_dotenv
load_dotenv()
app=Flask(__name__); app.secret_key=os.getenv("SECRET_KEY","change-me")
db=MongoClient(os.getenv("MONGODB_URI","mongodb://localhost:27017/"))[os.getenv("MONGODB_DB","vehicle_service_db")]
cols={n:db[n] for n in ["customers","vehicles","service_jobs","mechanics","spare_parts","invoices","feedback"]}
def add(name):
 d=request.form.to_dict(); d["created_at"]=datetime.utcnow(); cols[name].insert_one(d); flash("Saved successfully.","success")
@app.route("/")
def home(): return render_template("dashboard.html",counts=[cols[n].count_documents({}) for n in ["customers","vehicles","service_jobs","spare_parts"]],jobs=list(cols["service_jobs"].find().sort("created_at",-1).limit(8)))
@app.route("/health")
def health():
 try: db.command("ping"); return jsonify(status="ok",database="connected")
 except Exception as e: return jsonify(status="error",message=str(e)),500
@app.route("/<name>")
def listing(name):
 if name not in cols:return ("Not found",404)
 return render_template(name+".html",items=list(cols[name].find().sort("created_at",-1)))
@app.post("/<name>/add")
def create(name):
 if name not in cols:return ("Not found",404)
 add(name); return redirect(url_for("listing",name=name))
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.getenv("PORT",5000)),debug=True)
